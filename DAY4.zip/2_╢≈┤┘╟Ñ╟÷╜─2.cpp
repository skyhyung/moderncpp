// 5_����ǥ����1
#include <iostream>
#include <algorithm>
#include <functional>

int main()
{
	std::vector<int> v = { 1,3,5,7,9,2,4,6,8,10 };

	// sort �ϰ� �ʹٸ�
	std::sort(v.begin(), v.end(), [](int a, int b) { return a < b; });

}





