#include <unordered_set>

int main()
{
	std::unordered_set<int>    s1;
	std::unordered_set<double> s2;
}
